This project is built with .

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

~sushanth lakshmikaanth
